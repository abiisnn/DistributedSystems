g++ SocketMulticast.cpp PaqueteDatagrama.cpp emisor.cpp -o emisor -std=c++11

g++ SocketMulticast.cpp SocketDatagrama.cpp PaqueteDatagrama.cpp emisor2.cpp -o emisor2 -std=c++11