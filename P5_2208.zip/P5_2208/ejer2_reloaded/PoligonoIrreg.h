#ifndef PoligonoIrreg_H_
#define PoligonoIrreg_H_
#include "Coordenada.h"
#include <vector>
using namespace std;

class PoligonoIrreg{
private:
	vector<Coordenada> vertices;
public:
	PoligonoIrreg();
	void ordenaVertices();
	void imprimeVertices();
	void anadeVertice(Coordenada c);
};
#endif
