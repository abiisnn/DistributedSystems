#include "Coordenada.h"
#include "PoligonoIrreg.h"
#include <bits/stdc++.h>
using namespace std;

PoligonoIrreg::PoligonoIrreg(){}

void PoligonoIrreg::anadeVertice(Coordenada c){
	vertices.push_back(c);
}

void PoligonoIrreg::ordenaVertices(){
	sort(vertices.begin(),vertices.end(),[](Coordenada x, Coordenada y)-> bool{
		if(x.obtenerM() < y.obtenerM())
			return true;
		return false;
	});
}

void PoligonoIrreg::imprimeVertices(){
	cout << "Los vertices son: \n";
	vector <Coordenada>::iterator i;

	for(i=vertices.begin(); i!=vertices.end(); i++){
		cout <<"Vertice: (" << i->obtenerX() << "," << i->obtenerY() << ")\n";
		cout <<"\tMagnitud: (" << i-> obtenerM() << ") \n";
	}
}

