#include <bits/stdc++.h>
#include "Coordenada.h"
#include "PoligonoIrreg.h"
using namespace std;
#define endl '\n'

double Random(){
	double entero= -100+rand()%(101+100);
	double decimal= +100+rand()%(1000-100);
	return entero+decimal/1000;
}

int main(){
	srand(time(NULL));
	PoligonoIrreg *p = new PoligonoIrreg();
	int n;
	cin >> n;

	for(int i=0; i<n; i++){
		p->anadeVertice(Coordenada(Random(),Random()));
	}
	p->imprimeVertices();
	cout << "Vertices ordenados\n";
	p->ordenaVertices();
	p->imprimeVertices();

	return 0;
}

