#include "Coordenada.h"
#include <bits/stdc++.h>
using namespace std;

Coordenada::Coordenada(double xx, double yy) : x(xx), y(yy){
	m= sqrt( (xx*xx) + (yy*yy) );
}
double Coordenada::obtenerX()
{
	return x;
}
double Coordenada::obtenerY()
{
	return y;
}
double Coordenada::obtenerM(){
	return m;
}
