#include "Coordenada.h"
#include <bits/stdc++.h>
using namespace std;
#define PI 3.141592654 

Coordenada::Coordenada(double xx, double yy) //: x(xx), y(yy)
{ 
	x = xx * cos(yy*PI/180);
	//cout << "x es " << x << endl;
	y = xx * sin(yy*PI/180);
	//cout << "y es " << y << endl;
}
double Coordenada::obtenerX()
{
	return x;
}
double Coordenada::obtenerY()
{
	return y;
}
