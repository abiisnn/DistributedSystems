#ifndef Rectangulo_H_
#define Rectangulo_H_
#include "Coordenada.h"

class Rectangulo {
private:

	Coordenada superiorIzq;

	Coordenada inferiorDer;
public:

	Rectangulo();

//	Rectangulo(double xSupIzq, double ySupIzq, double xInfDer, double yInfDer);
	Rectangulo(Coordenada cordenada1, Coordenada cordenada2);

	void imprimeEsq();

	Coordenada obtieneSupIzq();

	Coordenada obtieneInfDer();

	// Agregado para la parte 3
	double obtieneArea();
};
#endif