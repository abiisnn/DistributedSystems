#include <bits/stdc++.h>
#include "Coordenada.h"
#include "PoligonoIrreg.h"
using namespace std;
int main(){
	int n,m;
	//cin >> n;
	n = 100000;
	m = 1000;
	vector<PoligonoIrreg> poli(n);
	for(PoligonoIrreg p: poli){
		p = PoligonoIrreg(m);
		for(int i =0; i < m; i++){
			p.anadeVertice(Coordenada(1,1));
		}
		//p.imprimeVertices();
	}
	return 0;
}