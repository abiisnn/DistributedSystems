#include "Coordenada.h"
#include "PoligonoIrreg.h"
#include <bits/stdc++.h>
using namespace std;

PoligonoIrreg::PoligonoIrreg(){}

PoligonoIrreg::PoligonoIrreg(int m){
	vertices.reserve(m);
}

void PoligonoIrreg::anadeVertice(Coordenada c){
	vertices.push_back(c);
}

void PoligonoIrreg::imprimeVertices(){
	cout << "Los vertices son: \n";
	for(Coordenada c:vertices){
		cout <<"Vertice: (" << c.obtenerX() << "," << c.obtenerY() << ")\n";
	}
}

