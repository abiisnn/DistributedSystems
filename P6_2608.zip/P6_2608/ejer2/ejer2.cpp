#include <bits/stdc++.h>
#include "Coordenada.h"
#include "PoligonoIrreg.h"
using namespace std;
#define endl '\n'
int main(){
	PoligonoIrreg *p = new PoligonoIrreg();
	while(true){
		int opc = 0;
		cout << "1.- Anadir un vertice.\n";
		cout << "2.- Imprimir todos los vertices.\n";
		cin >> opc;
		if(opc == 1){
			double a,b;
			cout << "Pon las coordenadas del vertice:\n";
			cin >> a >> b;
			p->anadeVertice(Coordenada(a,b));
			cout << "Vertice anadido!\n";
		}
		else if(opc == 2){
			p->imprimeVertices();
		}
		else
			cout << "ERROR\n";
	}
	return 0;
}

