import java.util.*;
public class pruebaJava{
	public static void main(String args[]){
		String alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int n = 175760;
		//System.out.println("HOLAAA");
		String s= "";
		for(int i =0;i < n; i++){
			String aux = "";
			for(int j =0; j < 3; j++){
				char c = alpha.charAt((int)(Math.random()*26));
				aux+=c;
			}
			if( i != n-1)
				aux+=" ";
			s+=aux;
		}
		//System.out.println(s);
		String ipn = "IPN";
		int cont =0;
		for(int i =0; i < n-2; i++){
			boolean flag = true;
			for(int j =0; j < 3; j++){
				if(s.charAt(i+j) != ipn.charAt(j)){
					flag= false;
					break;
				}
			}
			if(flag) cont++;
		}
		System.out.println(cont);
	}
}