import math
max = 10000000
i = 1
seno = 0
coseno = 0
tangente = 0
logaritmo = 0
raiz = 0
while i < max:
	seno += math.sin(i)
	coseno += math.cos(i)
	tangente += math.tan(i)
	logaritmo += math.log10(i)
	raiz += math.sqrt(i)
	i = i + 1
