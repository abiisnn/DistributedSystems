import java.lang.Math;
public class calculos {
    public static void main(String[] args) {

    	double i=0;
    	double seno=0, coseno=0, tangente=0, logaritmo=0, raizCuad=0;
    	int MAX= 10000000;

    	while(i<MAX){
    		seno+=Math.sin(i);
    		coseno+=Math.cos(i);
    		tangente+=Math.tan(i);
    		logaritmo+=Math.log(i);
    		raizCuad+=Math.sqrt(i);
    		i++;
    	}


     }
}