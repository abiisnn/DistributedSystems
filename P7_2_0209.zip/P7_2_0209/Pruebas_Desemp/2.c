#include<stdio.h>
#include<math.h>

int main() {
	double i = 0;
	double max;
	double seno, coseno, tangente, logaritmo, raiz;
	
	max = 10000000;
	while(i < max) {
		seno += sin(i);
		coseno += cos(i);
		tangente += tan(i);
		logaritmo += log(i);
		raiz += sqrt(i);
		i++;
	}
}

