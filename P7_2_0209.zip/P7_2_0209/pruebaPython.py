from random import randrange
alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
#print(alpha[randrange(27)])
n = 1757600
s = ""
for i in range(n):
	aux= ""
	for j in range(3):
		c = alpha[randrange(26)];
		aux+=str(c);
	if i != n-1:
		aux+=(" ");
	s+=(aux);
#print(s)
ipn = "IPN"
cont =0
for i in range(n-2):
	flag = 1
	for j in range(3):
		if s[i+j] != ipn[j]:
			flag = 0
			break
	if flag == 1: cont = cont+1
print(cont)